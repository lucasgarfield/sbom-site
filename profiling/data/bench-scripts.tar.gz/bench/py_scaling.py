#!/usr/bin/python3
"""
Python-side scaling benchmark: cost per stage vs number of packages n.

Loads the Fedora 44 repos (warm cache) with the real osbuild solver class,
samples n packages from all available packages (seeded, so every n is a
random mix and smaller sets are subsets of bigger ones), and times for each
metadata level (full, minimal):

  pkg_convert   dnf package -> model.Package     (solver code)
  disjoint      _transactions_to_disjoint_sets    (hashes the whole Package)
  pkg_dict      model.Package -> dict             (V2 serializer)
  json_dumps    json.dumps of the transaction list
  write         writing the string into a pipe read by `cat > /dev/null`

and, as cheap ESTIMATES of other encodings: gzip(-1) size+time, msgpack and
cbor2 size+time of the same dicts.

It also writes the V2 depsolve response for selected n to <out>/synthetic/
so the Go benchmarks can parse exactly the same payloads.

Usage (inside the benchmark container):
  py_scaling.py --solver dnf4 --request <captured depsolve request> --out runs/scaling
"""
import argparse
import gc
import gzip
import io
import json
import os
import random
import statistics
import subprocess
import sys
import tempfile
import time

sys.path.insert(0, os.environ.get("OSBUILD_SRC", "/workspace/depsolve-perf/osbuild"))

from osbuild.solver.api import v2  # noqa: E402
from osbuild.solver.model import DepsolveResult  # noqa: E402

try:
    import msgpack
except ImportError:
    msgpack = None
try:
    import cbor2
except ImportError:
    cbor2 = None


def t(fn):
    s = time.perf_counter()
    r = fn()
    return time.perf_counter() - s, r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--solver", choices=["dnf4", "dnf5"], required=True)
    ap.add_argument("--request", required=True, help="a captured V2 depsolve request (repos + cachedir)")
    ap.add_argument("--out", required=True)
    ap.add_argument("--sizes", default="10,30,100,300,1000,3000,10000,30000,all")
    ap.add_argument("--reps", type=int, default=5)
    ap.add_argument("--synthetic", default="10,30,100,300,1000,3000,10000,30000,all", help="sizes to write as V2 responses")
    ap.add_argument("--filelists", action="store_true")
    a = ap.parse_args()
    os.makedirs(os.path.join(a.out, "synthetic"), exist_ok=True)

    req = json.load(open(a.request, encoding="utf-8"))
    req["command"] = "dump"
    req["arguments"].pop("transactions", None)
    req["arguments"].pop("sbom", None)
    if a.filelists:
        req["arguments"]["optional-metadata"] = ["filelists"]
    request = v2.parse_request(req)

    if a.solver == "dnf5":
        import libdnf5 as dnf5

        import osbuild.solver.dnf5 as mod
        S = mod.DNF5
    else:
        import osbuild.solver.dnf as mod
        S = mod.DNF

    persist = tempfile.mkdtemp()
    init_s, solver = t(lambda: S(request.config, persist, None))
    if a.solver == "dnf5":
        q = dnf5.rpm.PackageQuery(solver.base)
        q.filter_available()
        allpkgs = list(q)
        allpkgs.sort(key=lambda p: p.get_nevra())
    else:
        allpkgs = list(solver.base.sack.query().available())
        allpkgs.sort(key=lambda p: str(p))
    N = len(allpkgs)
    rng = random.Random(42)
    order = list(range(N))
    rng.shuffle(order)
    repos = [solver._dnf_repo_to_repository(r) for r in (
        [solver.base.repos[i] for i in solver.base.repos] if a.solver == "dnf4" else [])]
    if a.solver == "dnf5":
        seen = {}
        for p in allpkgs:
            rid = p.get_repo().get_id()
            if rid not in seen:
                seen[rid] = solver._dnf_repo_to_repository(p.get_repo())
        repos = list(seen.values())
    print(f"solver={a.solver} init={init_s:.2f}s N={N}", flush=True)

    sizes = [N if s == "all" else int(s) for s in a.sizes.split(",")]
    synth = {N if s == "all" else int(s) for s in a.synthetic.split(",")}
    levels = {
        "full": (mod._dnf_pkg_to_package, v2._package_as_dict),
        "minimal": (mod._dnf_pkg_to_package_minimal, v2._package_as_dict_minimal),
    }
    out_path = os.path.join(a.out, f"py_scaling_{a.solver}{'_files' if a.filelists else ''}.jsonl")
    for n in sizes:
        n = min(n, N)
        sub = [allpkgs[i] for i in order[:n]]
        for level, (conv, as_dict) in levels.items():
            samples = {}
            info = {}
            for rep in range(a.reps):
                gc.collect()
                r = {}
                r["pkg_convert"], models = t(lambda: [conv(p) for p in sub])
                r["disjoint"], disj = t(lambda: v2._transactions_to_disjoint_sets([models]))
                r["pkg_dict"], dicts = t(lambda: [as_dict(m) for m in disj[0]])
                r["json_dumps"], s = t(lambda: json.dumps(dicts))
                b = s.encode()
                cat = subprocess.Popen(["cat"], stdin=subprocess.PIPE, stdout=subprocess.DEVNULL)
                r["write"], _ = t(lambda: (cat.stdin.write(b), cat.stdin.close(), cat.wait()))
                if rep == 0:
                    info["bytes"] = len(b)
                    info["reldeps"] = sum(len(m.provides) + len(m.requires) + len(m.requires_pre) +
                                          len(m.regular_requires) + len(m.conflicts) + len(m.obsoletes) +
                                          len(m.recommends) + len(m.suggests) + len(m.enhances) +
                                          len(m.supplements) for m in models)
                    info["files"] = sum(len(m.files) for m in models)
                    info["remote_locations"] = sum(len(m.remote_locations) for m in models)
                    r["est_gzip1"], gz = t(lambda: gzip.compress(b, 1))
                    info["est_gzip1_bytes"] = len(gz)
                    if msgpack:
                        r["est_msgpack"], mp = t(lambda: msgpack.packb(dicts))
                        info["est_msgpack_bytes"] = len(mp)
                        r["est_msgpack_decode"], _ = t(lambda: msgpack.unpackb(mp))
                        del mp
                    if cbor2:
                        r["est_cbor"], cb = t(lambda: cbor2.dumps(dicts))
                        info["est_cbor_bytes"] = len(cb)
                        del cb
                    r["est_json_loads"], _ = t(lambda: json.loads(s))
                    if n in synth:
                        fn = os.path.join(a.out, "synthetic",
                                          f"{a.solver}{'-files' if a.filelists else ''}-{level}-{n:06d}.response.json")
                        with open(fn, "w", encoding="utf-8") as f:
                            v2.serialize_response_depsolve(
                                "dnf5" if a.solver == "dnf5" else "dnf",
                                DepsolveResult([models], repos, {}, None), f,
                                package_metadata=v2.PackageMetadata(level))
                for k, val in r.items():
                    samples.setdefault(k, []).append(val)
                del models, disj, dicts, s, b
            rec = {"solver": a.solver, "filelists": a.filelists, "level": level, "n": n, **info,
                   "median": {k: statistics.median(v) for k, v in samples.items()},
                   "min": {k: min(v) for k, v in samples.items()},
                   "max": {k: max(v) for k, v in samples.items()},
                   "samples": samples}
            with open(out_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec) + "\n")
            md = rec["median"]
            print(f"n={n:6d} {level:7s} bytes={info['bytes']:>11d} conv={md['pkg_convert']:.3f} "
                  f"disj={md['disjoint']:.3f} dict={md['pkg_dict']:.3f} dumps={md['json_dumps']:.3f} "
                  f"write={md['write']:.3f}", flush=True)


if __name__ == "__main__":
    main()

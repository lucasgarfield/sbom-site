// dsbench drives depsolvednf directly (depsolve, dump, search) so the
// depsolver round trip can be measured for arbitrary package sets and whole
// repositories. Timings are recorded by the depsolvednf tracing
// (IMAGE_BUILDER_DEPSOLVE_TRACE), this tool only adds the wall time.
package main

import (
	"encoding/json"
	"bytes"
	"flag"
	"fmt"
	"os/exec"
	"strings"
	"time"

	"github.com/osbuild/image-builder/pkg/depsolvednf"
	"github.com/osbuild/image-builder/pkg/rpmmd"
	"github.com/osbuild/image-builder/pkg/sbom"
)

func main() {
	cmd := flag.String("cmd", "depsolve", "depsolve, dump or search")
	repoFile := flag.String("repos", "/workspace/depsolve-perf/image-builder/data/repositories/fedora-44.json", "repository json")
	repoNames := flag.String("repo-names", "", "comma separated repo names to use (default: all)")
	specs := flag.String("specs", "@core", "comma separated package specs (depsolve) or globs (search)")
	chain := flag.String("chain", "", "optional second transaction specs (comma separated)")
	weak := flag.Bool("weak", true, "install weak deps")
	level := flag.String("metadata", "", "package metadata level (full, minimal)")
	filelists := flag.Bool("filelists", false, "load filelists metadata")
	withSBOM := flag.Bool("sbom", false, "request an SPDX SBOM from the depsolver")
	cache := flag.String("cache", "/workspace/depsolve-perf/cache/warm", "rpmmd cache dir")
	tag := flag.String("tag", "", "free form tag written to the result line")
	pipeFile := flag.String("pipe-file", "", "cmd=pipe: file that a python child writes to its stdout")
	flag.Parse()

	if *cmd == "pipe" {
		pipeBench(*pipeFile, *tag)
		return
	}

	all, err := rpmmd.LoadRepositoriesFromFile(*repoFile)
	if err != nil {
		panic(err)
	}
	var repos []rpmmd.RepoConfig
	for _, r := range all["x86_64"] {
		if *repoNames == "" || strings.Contains(","+*repoNames+",", ","+r.Name+",") {
			repos = append(repos, r)
		}
	}

	solver := depsolvednf.NewSolver("platform:f44", "44", "x86_64", "fedora-44", *cache)
	lvl, err := depsolvednf.ParsePackageMetadata(*level)
	if err != nil {
		panic(err)
	}
	solver.SetPackageMetadata(lvl)
	if *filelists {
		solver.AddOptionalMetadata("filelists")
	}

	start := time.Now()
	n := 0
	switch *cmd {
	case "depsolve":
		sets := []rpmmd.PackageSet{{Include: strings.Split(*specs, ","), Repositories: repos, InstallWeakDeps: *weak}}
		if *chain != "" {
			sets = append(sets, rpmmd.PackageSet{Include: strings.Split(*chain, ","), Repositories: repos, InstallWeakDeps: *weak})
		}
		st := sbom.StandardTypeNone
		if *withSBOM {
			st = sbom.StandardTypeSpdx
		}
		res, err := solver.Depsolve(sets, st)
		if err != nil {
			panic(err)
		}
		for _, t := range res.Transactions {
			n += len(t)
		}
	case "dump":
		pkgs, err := solver.FetchMetadata(repos)
		if err != nil {
			panic(err)
		}
		n = len(pkgs)
	case "search":
		pkgs, err := solver.SearchMetadata(repos, strings.Split(*specs, ","))
		if err != nil {
			panic(err)
		}
		n = len(pkgs)
	default:
		panic("unknown cmd " + *cmd)
	}
	out, _ := json.Marshal(map[string]any{
		"cmd": *cmd, "specs": *specs, "metadata": *level, "filelists": *filelists, "sbom": *withSBOM,
		"tag": *tag, "packages": n, "wall_ns": time.Since(start).Nanoseconds(),
	})
	fmt.Println(string(out))
}

// pipeBench measures the raw cost of moving a payload from a Python child
// process to Go over a pipe, the same way depsolvednf.run() does (stdout
// into a bytes.Buffer), without any JSON work on either side.
func pipeBench(file, tag string) {
	script := `import sys,time
d=open(sys.argv[1],"rb").read()
sys.stderr.write("%.9f\n" % time.time())
sys.stdout.buffer.write(d)
sys.stdout.flush()`
	c := exec.Command("python3", "-c", script, file)
	var out, errb bytes.Buffer
	tw := &firstLast{w: &out}
	c.Stdout = tw
	c.Stderr = &errb
	start := time.Now()
	if err := c.Run(); err != nil {
		panic(err)
	}
	total := time.Since(start)
	o, _ := json.Marshal(map[string]any{"cmd": "pipe", "tag": tag, "bytes": out.Len(),
		"transfer_ns": tw.last.Sub(tw.first).Nanoseconds(), "process_ns": total.Nanoseconds()})
	fmt.Println(string(o))
}

type firstLast struct {
	w           *bytes.Buffer
	first, last time.Time
}

func (f *firstLast) Write(p []byte) (int, error) {
	now := time.Now()
	if f.first.IsZero() {
		f.first = now
	}
	n, err := f.w.Write(p)
	f.last = time.Now()
	return n, err
}

module dsbench

go 1.25.0

require github.com/osbuild/image-builder v0.0.0

require (
	github.com/gobwas/glob v0.2.3 // indirect
	github.com/hashicorp/go-version v1.9.0 // indirect
	go.yaml.in/yaml/v3 v3.0.4 // indirect
	gopkg.in/ini.v1 v1.67.3 // indirect
)

replace github.com/osbuild/image-builder => ../../image-builder

#!/usr/bin/python3
"""
Drop-in replacement for osbuild-depsolve-dnf that runs the real tool code
(from $OSBUILD_SRC) with per-stage timers.

Env:
  OSBUILD_SRC            osbuild checkout (default /workspace/depsolve-perf/osbuild)
  OSBUILD_SOLVER_CONFIG  solver.json ({"use_dnf5": true} for dnf5)
  PERF_PY_TRACE          append one JSON line with stage timings here
  PERF_PY_CPROFILE       write cProfile stats (pstats format) to this path
  PERF_PY_NOTIMERS=1     do not install the per-call wrappers (to measure their overhead)

Stage timers wrap module-level functions, so they include a small per-call
overhead (~0.2-0.5 us per wrapped call); see REPORT.md.
"""
import json
import os
import resource
import sys
import time

T0 = time.perf_counter()
SRC = os.environ.get("OSBUILD_SRC", "/workspace/depsolve-perf/osbuild")
sys.path.insert(0, SRC)

acc = {}
cnt = {}


def add(name, dt, n=1):
    acc[name] = acc.get(name, 0.0) + dt
    cnt[name] = cnt.get(name, 0) + n


def timed(name, fn):
    pc = time.perf_counter

    def w(*a, **kw):
        t = pc()
        try:
            return fn(*a, **kw)
        finally:
            add(name, pc() - t)
    w.__wrapped__ = fn
    return w


def main():
    import importlib.machinery
    import importlib.util

    t = time.perf_counter()
    loader = importlib.machinery.SourceFileLoader("depsolve_tool", os.path.join(SRC, "tools/osbuild-depsolve-dnf"))
    spec = importlib.util.spec_from_loader("depsolve_tool", loader)
    tool = importlib.util.module_from_spec(spec)
    loader.exec_module(tool)  # imports dnf or libdnf5
    add("import", time.perf_counter() - t)

    from osbuild.solver import api
    from osbuild.solver.api import v2
    use_dnf5 = tool.config.get("use_dnf5", False)
    if use_dnf5:
        import osbuild.solver.dnf5 as solvmod
    else:
        import osbuild.solver.dnf as solvmod

    if os.environ.get("PERF_PY_NOTIMERS") != "1":
        # package conversion (dnf package -> model.Package)
        solvmod._dnf_pkg_to_package = timed("pkg_convert", solvmod._dnf_pkg_to_package)
        solvmod._dnf_pkg_to_package_minimal = timed("pkg_convert", solvmod._dnf_pkg_to_package_minimal)
        # model.Package -> dict
        v2._package_as_dict = timed("pkg_dict", v2._package_as_dict)
        v2._package_as_dict_minimal = timed("pkg_dict", v2._package_as_dict_minimal)
        v2._transactions_to_disjoint_sets = timed("disjoint_sets", v2._transactions_to_disjoint_sets)

        class TimedJSON:
            loads = staticmethod(json.loads)
            dumps = staticmethod(timed("json_dumps", json.dumps))
        v2.json = TimedJSON

    # solver phases
    S = tool.Solver
    S.__init__ = timed("solver_init", S.__init__)
    S.depsolve = timed("solve_cmd", S.depsolve)
    S.dump = timed("solve_cmd", S.dump)
    S.search = timed("solve_cmd", S.search)
    if hasattr(S, "_sbom_for_pkgset"):
        S._sbom_for_pkgset = timed("sbom", S._sbom_for_pkgset)
    if not use_dnf5:
        import dnf
        import dnf.repo
        # Repo.load(): check/download repo metadata (network unless fresh)
        dnf.repo.Repo.load = timed("repo_md_load", dnf.repo.Repo.load)
        # _add_repo_to_sack(): Repo.load() + loading the solv/xml into the sack
        dnf.Base._add_repo_to_sack = timed("repo_add_to_sack", dnf.Base._add_repo_to_sack)
    else:
        import libdnf5
        for cls in (libdnf5.repo.RepoSack, getattr(libdnf5.repo, "RepoSackWeakPtr", None)):
            if cls is not None and hasattr(cls, "load_repos"):
                cls.load_repos = timed("repo_load_repos", cls.load_repos)
    for name in ("serialize_response_depsolve", "serialize_response_dump", "serialize_response_search"):
        setattr(api, name, timed("serialize", getattr(api, name)))
    api.parse_request = timed("parse_request", api.parse_request)

    class TimedWriter:
        def __init__(self, w):
            self.w = w
            self.n = 0

        def write(self, s):
            t = time.perf_counter()
            r = self.w.write(s)
            add("stdout_write", time.perf_counter() - t)
            self.n += len(s)
            return r

        def flush(self):
            self.w.flush()

    t = time.perf_counter()
    raw = sys.stdin.read()
    add("read_stdin", time.perf_counter() - t)
    t = time.perf_counter()
    request_dict = json.loads(raw)
    add("json_load_request", time.perf_counter() - t)

    writer = TimedWriter(sys.stdout)
    prof = None
    if os.environ.get("PERF_PY_CPROFILE"):
        import cProfile
        prof = cProfile.Profile()
        prof.enable()
    t = time.perf_counter()
    err = tool.solve(request_dict, writer)
    add("solve_total", time.perf_counter() - t)
    if prof:
        prof.disable()
        prof.dump_stats(os.environ["PERF_PY_CPROFILE"])
    t = time.perf_counter()
    sys.stdout.flush()
    add("stdout_flush", time.perf_counter() - t)

    rec = {
        "pid": os.getpid(),
        "command": request_dict.get("command"),
        "package_metadata": request_dict.get("arguments", {}).get("package_metadata", "full"),
        "solver": "dnf5" if use_dnf5 else "dnf4",
        "sbom": "sbom" in request_dict.get("arguments", {}),
        "optional_metadata": request_dict.get("arguments", {}).get("optional-metadata"),
        "bytes_out": writer.n,
        "maxrss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "wall_in_python": time.perf_counter() - T0,
        "stages": acc,
        "calls": cnt,
        "error": err["kind"] if err else None,
    }
    if os.environ.get("PERF_PY_TRACE"):
        with open(os.environ["PERF_PY_TRACE"], "a", encoding="utf-8") as f:
            f.write(json.dumps(rec) + "\n")
    if err:
        tool.fail(err)


if __name__ == "__main__":
    main()

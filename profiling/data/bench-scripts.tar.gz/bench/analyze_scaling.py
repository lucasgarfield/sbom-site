#!/usr/bin/python3
"""
Scaling analysis: per-stage cost vs number of packages n and vs payload bytes.

Inputs:
  runs/scaling/py_scaling_*.jsonl   (py_scaling.py)
  runs/scaling/go_bench.txt         (go test -bench output on runs/scaling/synthetic/*)
Outputs: plots/*.png and runs/scaling/fits.md
"""
import glob
import json
import math
import os
import re
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

ROOT = sys.argv[1] if len(sys.argv) > 1 else "/workspace/depsolve-perf"
SC = f"{ROOT}/runs/scaling"
PL = f"{ROOT}/plots"
os.makedirs(PL, exist_ok=True)


def fit(ns, ts, nmin=100):
    """Fit log t = a + b log n (n >= nmin) and t = c + k n. Returns b, k, c, r2_lin."""
    pts = [(n, t) for n, t in zip(ns, ts) if n >= nmin and t > 0]
    if len(pts) < 3:
        return None
    x = np.array([p[0] for p in pts], dtype=float)
    y = np.array([p[1] for p in pts], dtype=float)
    b, a = np.polyfit(np.log(x), np.log(y), 1)
    k, c = np.polyfit(x, y, 1)
    pred = c + k * x
    r2 = 1 - ((y - pred) ** 2).sum() / ((y - y.mean()) ** 2).sum()
    return {"exponent": b, "per_unit": k, "intercept": c, "r2_linear": r2}


def load_py():
    recs = []
    for f in sorted(glob.glob(f"{SC}/py_scaling_*.jsonl")):
        with open(f, encoding="utf-8") as fh:
            recs += [json.loads(line) for line in fh]
    return recs


def load_go(name="go_bench.txt"):
    raw = load_go_raw(name)
    groups = {}
    for x in raw:
        groups.setdefault((x["bench"], x["solver"], x["files"], x["level"], x["n"]), []).append(x)
    out = []
    for k, xs in groups.items():
        xs = sorted(xs, key=lambda x: x["ns"])
        m = dict(xs[len(xs) // 2])
        m["ns_min"], m["ns_max"], m["count"] = xs[0]["ns"], xs[-1]["ns"], len(xs)
        out.append(m)
    return out


def load_go_raw(name):
    out = []
    path = f"{SC}/{name}"
    if not os.path.exists(path):
        return out
    rx = re.compile(r"^BenchmarkV2Parse(\w+)/(dnf\d)(-files)?-(full|minimal)-(\d+)\.response\.json-\d+\s+(\d+)\s+([\d.]+) ns/op\s+([\d.]+) MB/s\s+(\d+) B/op\s+(\d+) allocs/op")
    for line in open(path, encoding="utf-8"):
        m = rx.match(line.strip())
        if m:
            out.append({"bench": m.group(1), "solver": m.group(2), "files": bool(m.group(3)), "level": m.group(4),
                        "n": int(m.group(5)), "ns": float(m.group(7)), "mbps": float(m.group(8)),
                        "bytes_alloc": int(m.group(9)), "allocs": int(m.group(10))})
    return out


def main():
    py = load_py()
    go = load_go()
    lines = ["| solver | files | level | stage | exponent b (t ∝ n^b) | µs per package | ns per payload byte | R² (linear) |",
             "|---|---|---|---|---|---|---|---|"]
    stages = ["pkg_convert", "disjoint", "pkg_dict", "json_dumps", "write"]
    combos = sorted({(r["solver"], r["filelists"], r["level"]) for r in py})
    # --- plot 1: per-stage time vs n (Python), per solver
    for solver in ("dnf4", "dnf5"):
        fig, axes = plt.subplots(1, 2, figsize=(14, 5.5), sharey=True)
        for ax, level in zip(axes, ("full", "minimal")):
            rs = sorted([r for r in py if r["solver"] == solver and r["level"] == level and not r["filelists"]],
                        key=lambda r: r["n"])
            if not rs:
                continue
            ns = [r["n"] for r in rs]
            for st in stages:
                ts = [r["median"][st] for r in rs]
                lo = [r["min"][st] for r in rs]
                hi = [r["max"][st] for r in rs]
                ax.errorbar(ns, ts, yerr=[np.subtract(ts, lo), np.subtract(hi, ts)], marker="o", ms=3,
                            label=f"Py {st}", capsize=2)
            g = sorted([x for x in go if x["solver"] == solver and x["level"] == level and not x["files"]],
                       key=lambda x: x["n"])
            for bench in ("Unmarshal", "Full"):
                gg = [x for x in g if x["bench"] == bench]
                if gg:
                    ax.plot([x["n"] for x in gg], [x["ns"] / 1e9 for x in gg], marker="s", ms=3, ls="--",
                            label=f"Go {'json.Unmarshal' if bench == 'Unmarshal' else 'Unmarshal+convert'}")
            ax.set_xscale("log")
            ax.set_yscale("log")
            ax.set_xlabel("packages in response (n)")
            ax.set_title(f"{solver}, {level} metadata")
            ax.grid(True, which="both", alpha=0.3)
        axes[0].set_ylabel("seconds (median, min–max bars)")
        axes[0].legend(fontsize=8)
        fig.suptitle("Per-stage cost vs number of packages (random samples of all Fedora 44 packages)")
        fig.tight_layout()
        fig.savefig(f"{PL}/scaling_stages_{solver}.png", dpi=110)
        plt.close(fig)

    # --- plot 2: payload bytes vs n
    fig, ax = plt.subplots(figsize=(8, 5.5))
    for solver, files, level in combos:
        rs = sorted([r for r in py if (r["solver"], r["filelists"], r["level"]) == (solver, files, level)],
                    key=lambda r: r["n"])
        ax.plot([r["n"] for r in rs], [r["bytes"] for r in rs], marker="o", ms=3,
                label=f"{solver} {level}{' +filelists' if files else ''}")
        if level == "full" and solver == "dnf4" and not files:
            ax.plot([r["n"] for r in rs], [r["est_gzip1_bytes"] for r in rs], ls=":", label="dnf4 full, gzip -1 (estimate)")
            if "est_msgpack_bytes" in rs[0]:
                ax.plot([r["n"] for r in rs], [r["est_msgpack_bytes"] for r in rs], ls="-.",
                        label="dnf4 full, msgpack (estimate)")
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("packages (n)")
    ax.set_ylabel("JSON payload bytes")
    ax.grid(True, which="both", alpha=0.3)
    ax.legend(fontsize=8)
    ax.set_title("Depsolver payload size vs n")
    fig.tight_layout()
    fig.savefig(f"{PL}/scaling_bytes.png", dpi=110)
    plt.close(fig)

    # --- plot 3: time vs bytes (json.dumps and Go unmarshal)
    fig, ax = plt.subplots(figsize=(8, 5.5))
    for solver, files, level in combos:
        rs = [r for r in py if (r["solver"], r["filelists"], r["level"]) == (solver, files, level)]
        ax.scatter([r["bytes"] for r in rs], [r["median"]["json_dumps"] for r in rs], s=12,
                   label=f"Py json.dumps {solver} {level}{' +fl' if files else ''}")
        g = [x for x in go if (x["solver"], x["files"], x["level"]) == (solver, files, level) and x["bench"] == "Unmarshal"]
        if g:
            byts = {r["n"]: r["bytes"] for r in rs}
            pts = [(byts.get(x["n"]), x["ns"] / 1e9) for x in g if byts.get(x["n"])]
            ax.scatter([p[0] for p in pts], [p[1] for p in pts], marker="x", s=20,
                       label=f"Go Unmarshal {solver} {level}{' +fl' if files else ''}")
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("payload bytes")
    ax.set_ylabel("seconds")
    ax.grid(True, which="both", alpha=0.3)
    ax.legend(fontsize=7)
    ax.set_title("Serialization / deserialization time vs payload bytes")
    fig.tight_layout()
    fig.savefig(f"{PL}/scaling_time_vs_bytes.png", dpi=110)
    plt.close(fig)

    # --- fits
    for solver, files, level in combos:
        rs = sorted([r for r in py if (r["solver"], r["filelists"], r["level"]) == (solver, files, level)],
                    key=lambda r: r["n"])
        ns = [r["n"] for r in rs]
        for st in stages:
            f = fit(ns, [r["median"][st] for r in rs])
            fb = fit([r["bytes"] for r in rs], [r["median"][st] for r in rs], nmin=1)
            if f:
                lines.append(f"| {solver} | {files} | {level} | Py {st} | {f['exponent']:.2f} | {f['per_unit']*1e6:.2f} | "
                             f"{fb['per_unit']*1e9:.2f} | {f['r2_linear']:.3f} |")
        byts = {r["n"]: r["bytes"] for r in rs}
        for bench in ("Unmarshal", "Full"):
            g = sorted([x for x in go if (x["solver"], x["files"], x["level"], x["bench"]) == (solver, files, level, bench)],
                       key=lambda x: x["n"])
            if len(g) >= 3:
                f = fit([x["n"] for x in g], [x["ns"] / 1e9 for x in g])
                fb = fit([byts.get(x["n"], 0) for x in g], [x["ns"] / 1e9 for x in g], nmin=1)
                if f:
                    lines.append(f"| {solver} | {files} | {level} | Go {bench} | {f['exponent']:.2f} | "
                                 f"{f['per_unit']*1e6:.2f} | {fb['per_unit']*1e9:.2f} | {f['r2_linear']:.3f} |")
    # full table of the largest n
    big = ["", "| solver | files | level | n | bytes | gzip-1 (est.) | msgpack (est.) | cbor (est.) | Py convert s | Py dict s | Py dumps s | Py write s | Py msgpack.packb s (est.) | Go Unmarshal s | Go Unmarshal+convert s |",
           "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in sorted(py, key=lambda r: (r["solver"], r["filelists"], r["level"], r["n"])):
        g = {x["bench"]: x for x in go if (x["solver"], x["files"], x["level"], x["n"]) == (r["solver"], r["filelists"], r["level"], r["n"])}
        md = r["median"]
        big.append(f"| {r['solver']} | {r['filelists']} | {r['level']} | {r['n']} | {r['bytes']/1e6:.2f} MB | "
                   f"{r.get('est_gzip1_bytes', 0)/1e6:.2f} MB | {r.get('est_msgpack_bytes', 0)/1e6:.2f} MB | "
                   f"{r.get('est_cbor_bytes', 0)/1e6:.2f} MB | {md['pkg_convert']:.3f} | {md['pkg_dict']:.3f} | "
                   f"{md['json_dumps']:.3f} | {md['write']:.3f} | {md.get('est_msgpack', float('nan')):.3f} | "
                   f"{g['Unmarshal']['ns']/1e9 if 'Unmarshal' in g else float('nan'):.3f} | "
                   f"{g['Full']['ns']/1e9 if 'Full' in g else float('nan'):.3f} |")
    # encoding/json vs GOEXPERIMENT=jsonv2 (estimate, same Go code)
    j2 = {(x["bench"], x["solver"], x["files"], x["level"], x["n"]): x for x in load_go("go_bench_jsonv2.txt")}
    cmp_ = ["", "| level | n | bench | encoding/json (v1) s | GOEXPERIMENT=jsonv2 s (estimate) | speedup |", "|---|---|---|---|---|---|"]
    for x in sorted(go, key=lambda x: (x["level"], x["n"], x["bench"])):
        k = (x["bench"], x["solver"], x["files"], x["level"], x["n"])
        if k in j2:
            cmp_.append(f"| {x['level']} | {x['n']} | {x['bench']} | {x['ns']/1e9:.4f} | {j2[k]['ns']/1e9:.4f} | {x['ns']/j2[k]['ns']:.2f}x |")
    with open(f"{SC}/fits.md", "w", encoding="utf-8") as f:
        f.write("\n".join(lines + big + cmp_) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()

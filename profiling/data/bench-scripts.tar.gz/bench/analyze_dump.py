#!/usr/bin/env python3
"""Summarize whole-repo dump/search runs (runs/dump) into runs/dump/tables.md."""
import json, statistics as st, collections, sys
R = sys.argv[1] if len(sys.argv) > 1 else "runs/dump"
wall = collections.defaultdict(list)
for l in open(f"{R}/results.jsonl"):
    d = json.loads(l); wall[(d["tag"].rsplit("-", 1)[0], d["cmd"])].append(d["wall_ns"] / 1e9)
py = collections.defaultdict(list)
for l in open(f"{R}/py.jsonl"):
    d = json.loads(l); py[(d["solver"] + "-" + d["package_metadata"], d["command"])].append(d)
go = collections.defaultdict(list)
for l in open(f"{R}/go.jsonl"):
    d = json.loads(l); go[d["command"], d["package_metadata"]].append(d)
med = lambda xs: st.median(xs) if xs else float("nan")
out = ["| solver-metadata | cmd | runs ok | wall s (median, min–max) | py import | py repo load | py pkg_convert | py dict | py json.dumps | py write | Go Unmarshal | Go convert | payload MB | py RSS MiB | Go RSS MiB |",
       "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
for key in [("dnf4-full","dump"),("dnf4-full","search"),("dnf4-minimal","dump"),("dnf4-minimal","search"),
            ("dnf5-full","dump"),("dnf5-full","search"),("dnf5-minimal","dump"),("dnf5-minimal","search")]:
    w = wall.get(key, []); p = py.get(key, [])
    g = [x for x in go.get((key[1], key[0].split("-")[1]), []) if x.get("packages") and
         (x.get("field_coverage", {}).get("remote_locations", 0) > 0) == True]
    s = lambda name: med([x["stages"].get(name, 0) for x in p])
    if not w:
        out.append(f"| {key[0]} | {key[1]} | 0/3 | OOM-killed at 4 GiB | | | | | | | | | | | |"); continue
    # go records: match by solver via response size order is ambiguous -> use solver tag in trace if present
    gs = [x for x in go.get((key[1], key[0].split("-")[1]), []) if x.get("solver", key[0][:4]) == key[0][:4]]
    gs = [x for x in gs if abs(x["response_bytes"] - med([q["bytes_out"] for q in p] or [0])) < 1e6] if p else gs
    gm = lambda f: med([x[f] for x in gs]) / 1e9
    repo = s("repo_md_load") + s("repo_add_to_sack") + s("repo_load_repos")
    out.append(f"| {key[0]} | {key[1]} | {len(w)}/3 | {med(w):.2f} ({min(w):.2f}–{max(w):.2f}) | {s('import'):.2f} | {repo:.2f} | "
               f"{s('pkg_convert'):.2f} | {s('pkg_dict'):.2f} | {s('json_dumps'):.2f} | {s('stdout_write'):.2f} | "
               f"{gm('unmarshal_ns'):.2f} | {gm('convert_ns'):.2f} | {med([q['bytes_out'] for q in p])/1e6:.0f} | "
               f"{med([q['maxrss_kib'] for q in p])/1024:.0f} | {med([x['self_maxrss_kib'] for x in gs])/1024:.0f} |")
open(f"{R}/tables.md", "w").write("\n".join(out) + "\n"); print("\n".join(out))

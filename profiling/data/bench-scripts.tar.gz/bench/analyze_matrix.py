#!/usr/bin/python3
"""
Aggregate runs/<name>/results.jsonl (from run_matrix.py) into per-stage
tables (median, min-max) and a stacked-bar plot.

  analyze_matrix.py runs/warm --md runs/warm/tables.md --plot plots/stages_warm.png
"""
import argparse
import json
import statistics
from collections import defaultdict

PY_STAGES = [
    # (key, label)
    ("py_startup", "Py interpreter start (before harness)"),
    ("import", "Py import dnf/libdnf5 + tool"),
    ("request", "Py read+parse request"),
    ("repo_load", "Py repo metadata load (solver init)"),
    ("depsolve", "Py depsolve (resolve, minus convert/SBOM)"),
    ("pkg_convert", "Py dnf pkg -> model.Package"),
    ("sbom", "Py SPDX SBOM in depsolver"),
    ("disjoint", "Py disjoint sets (hash Packages)"),
    ("pkg_dict", "Py model.Package -> dict"),
    ("json_dumps", "Py json.dumps"),
    ("write", "Py stdout write+flush"),
    ("py_teardown", "Py exit/teardown after output"),
]
GO_STAGES = [
    ("go_marshal", "Go marshal request"),
    ("go_unmarshal", "Go json.Unmarshal"),
    ("go_convert", "Go convert to rpmmd"),
    ("go_post_other", "Go other post-processing (incl. SBOM doc)"),
]
METADATA_STAGES = ["pkg_convert", "disjoint", "pkg_dict", "json_dumps", "write", "go_unmarshal", "go_convert"]


def per_call(g, p):
    """Stage seconds of one depsolver call from the Go and Python trace records."""
    s = {}
    st = p["stages"] if p else {}
    s["py_startup"] = max(0.0, g["process_ns"] / 1e9 - p["wall_in_python"]) if p else 0.0
    s["import"] = st.get("import", 0)
    s["request"] = st.get("read_stdin", 0) + st.get("json_load_request", 0) + st.get("parse_request", 0)
    s["repo_load"] = st.get("solver_init", 0)
    s["repo_md_load"] = st.get("repo_md_load", 0)  # dnf4 only, part of repo_load
    s["pkg_convert"] = st.get("pkg_convert", 0)
    s["sbom"] = st.get("sbom", 0)
    s["depsolve"] = st.get("solve_cmd", 0) - s["pkg_convert"] - s["sbom"]
    s["disjoint"] = st.get("disjoint_sets", 0)
    s["pkg_dict"] = st.get("pkg_dict", 0)
    s["json_dumps"] = st.get("json_dumps", 0)
    s["write"] = st.get("stdout_write", 0) + st.get("stdout_flush", 0)
    if p:
        accounted = s["import"] + s["request"] + st.get("solve_total", 0) + st.get("stdout_flush", 0)
        s["py_teardown"] = max(0.0, p["wall_in_python"] - accounted)
        # residual of solve_total not in solver/serializer stages
        s["py_other"] = st.get("solve_total", 0) - st.get("solver_init", 0) - st.get("solve_cmd", 0) - st.get("serialize", 0)
    s["go_marshal"] = g["marshal_request_ns"] / 1e9
    s["go_unmarshal"] = g["unmarshal_ns"] / 1e9
    s["go_convert"] = g["convert_ns"] / 1e9
    s["go_post_other"] = (g["post_ns"] - g["unmarshal_ns"] - g["convert_ns"]) / 1e9
    s["go_process"] = g["process_ns"] / 1e9
    s["go_total"] = g["total_ns"] / 1e9
    s["transfer_window"] = (g["last_byte_ns"] - g["first_byte_ns"]) / 1e9
    s["bytes"] = g["response_bytes"]
    s["sbom_bytes"] = g.get("sbom_bytes", 0)
    s["packages"] = g["packages"]
    s["py_maxrss_mib"] = g["child_maxrss_kib"] / 1024
    s["go_maxrss_mib"] = g["self_maxrss_kib"] / 1024
    s["reldeps"] = g["reldeps"]
    s["files"] = g["files"]
    return s


def per_run(r):
    calls = [per_call(g, p) for g, p in zip(r["go"], r["py"] + [None] * (len(r["go"]) - len(r["py"])))]
    agg = defaultdict(float)
    for c in calls:
        for k, v in c.items():
            if k.endswith("maxrss_mib"):
                agg[k] = max(agg[k], v)
            else:
                agg[k] += v
    agg["calls"] = len(calls)
    agg["wall"] = r["wall_s"]
    agg["ib_rest"] = r["wall_s"] - agg["go_total"]
    agg["metadata_cost"] = sum(agg[k] for k in METADATA_STAGES)
    agg["ib_maxrss_mib"] = r["ib_maxrss_kib"] / 1024
    return dict(agg)


def load(path):
    groups = defaultdict(list)
    with open(path, encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            if r["rc"] != 0:
                continue
            groups[(r["image"], r["solver"], r["variant"], r["cache"])].append(per_run(r))
    return groups


def med(vals):
    return statistics.median(vals)


def fmt_s(vals, unit="ms"):
    m = med(vals)
    lo, hi = min(vals), max(vals)
    if unit == "ms":
        return f"{m*1000:.0f} ({lo*1000:.0f}–{hi*1000:.0f})"
    return f"{m:.2f} ({lo:.2f}–{hi:.2f})"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run_dir")
    ap.add_argument("--md")
    ap.add_argument("--json")
    ap.add_argument("--plot")
    ap.add_argument("--variants", default="today,full,minimal,full_files")
    a = ap.parse_args()
    groups = load(f"{a.run_dir}/results.jsonl")
    variants = a.variants.split(",")
    images = []
    for (img, _, _, _) in groups:
        if img not in images:
            images.append(img)
    out = []
    summary = {}
    for solver in ("dnf4", "dnf5"):
        for img in images:
            keys = [(img, solver, v, c) for v in variants for c in ("warm", "cold") if (img, solver, v, c) in groups]
            if not keys:
                continue
            cols = [k[2] + ("" if k[3] == "warm" else " (cold)") for k in keys]
            runs = [groups[k] for k in keys]
            n = runs[0][0]["packages"]
            out.append(f"\n#### {img} — {solver} — {int(n)} packages over {int(runs[0][0]['calls'])} depsolve calls, "
                       f"{len(runs[0])} reps\n")
            out.append("| stage (sum over calls), median (min–max) ms | " + " | ".join(cols) + " |")
            out.append("|---" * (len(cols) + 1) + "|")

            def row(label, key, unit="ms", conv=lambda x: x):
                vals = [[conv(r[key]) for r in rs] for rs in runs]
                if unit == "ms":
                    cells = [fmt_s(v) for v in vals]
                elif unit == "MB":
                    cells = [f"{med(v)/1e6:.2f}" for v in vals]
                elif unit == "MiB":
                    cells = [f"{med(v):.0f}" for v in vals]
                elif unit == "%":
                    cells = [f"{med(v)*100:.1f}%" for v in vals]
                else:
                    cells = [f"{med(v):.0f}" for v in vals]
                out.append(f"| {label} | " + " | ".join(cells) + " |")
            row("response payload (MB)", "bytes", "MB")
            row("  of which depsolver SBOM (MB)", "sbom_bytes", "MB")
            row("reldeps / files returned", "reldeps", "n")
            for k, lab in PY_STAGES:
                row(lab, k)
            if solver == "dnf4":
                row("  (of repo load: Repo.load md check)", "repo_md_load")
            for k, lab in GO_STAGES:
                row(lab, k)
            row("**metadata-dependent stages** (convert+disjoint+dict+dumps+write+unmarshal+convert)", "metadata_cost")
            row("depsolver process (Go view)", "go_process")
            row("output arrival window (first→last byte)", "transfer_window")
            row("rest of image-builder (not depsolve)", "ib_rest")
            row("**total wall**", "wall")
            for r_ in runs:
                for x in r_:
                    x["metadata_share"] = x["metadata_cost"] / x["wall"]
            row("metadata-dependent share of wall", "metadata_share", "%")
            row("peak RSS Python (MiB, max over calls)", "py_maxrss_mib", "MiB")
            row("peak RSS image-builder Go process (MiB)", "go_maxrss_mib", "MiB")
            for k, rs in zip(keys, runs):
                summary["|".join(k)] = {kk: med([r[kk] for r in rs]) for kk in rs[0]}
    if a.md:
        with open(a.md, "w", encoding="utf-8") as f:
            f.write("\n".join(out) + "\n")
    else:
        print("\n".join(out))
    if a.json:
        with open(a.json, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=1)
    if a.plot:
        plot(groups, images, variants, a.plot)


def plot(groups, images, variants, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    stages = [
        ("py_startup", "Py start+import", ["py_startup", "import"]),
        ("repo_load", "Py repo load", ["repo_load"]),
        ("depsolve", "Py depsolve", ["depsolve", "request"]),
        ("sbom", "Py SBOM", ["sbom"]),
        ("pkg_convert", "Py pkg convert", ["pkg_convert"]),
        ("ser", "Py dict+disjoint+dumps+write", ["pkg_dict", "disjoint", "json_dumps", "write"]),
        ("teardown", "Py teardown", ["py_teardown"]),
        ("go", "Go unmarshal+convert", ["go_unmarshal", "go_convert"]),
        ("gorest", "image-builder rest", ["ib_rest"]),
    ]
    colors = ["#bbbbbb", "#4c72b0", "#55a868", "#8172b2", "#c44e52", "#dd8452", "#999999", "#da8bc3", "#e5e5e5"]
    fig, axes = plt.subplots(1, 2, figsize=(16, 7), sharey=True)
    for ax, solver in zip(axes, ("dnf4", "dnf5")):
        labels, bottoms = [], None
        xs = []
        data = []
        for img in images:
            for v in variants:
                k = (img, solver, v, "warm")
                if k not in groups:
                    continue
                rs = groups[k]
                labels.append(f"{img}\n{v}")
                data.append([med([sum(r[s] for s in subs) for r in rs]) for _, _, subs in stages])
        xs = range(len(labels))
        bottoms = [0.0] * len(labels)
        for si, (key, lab, _) in enumerate(stages):
            vals = [d[si] for d in data]
            ax.bar(xs, vals, bottom=bottoms, color=colors[si], label=lab, edgecolor="white", linewidth=0.3)
            bottoms = [b + v for b, v in zip(bottoms, vals)]
        ax.set_xticks(list(xs))
        ax.set_xticklabels(labels, rotation=90, fontsize=7)
        ax.set_title(f"image-builder manifest, warm cache, {solver} (median of reps)")
        ax.set_ylabel("seconds (sum over depsolve calls; 'rest' = wall − depsolve)")
    axes[0].legend(fontsize=8, loc="upper left")
    fig.tight_layout()
    fig.savefig(path, dpi=110)


if __name__ == "__main__":
    main()

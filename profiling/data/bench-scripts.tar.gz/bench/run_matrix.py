#!/usr/bin/python3
"""
Run `image-builder manifest` for a matrix of image types x metadata variants x
solvers x repetitions, with Go-side (IMAGE_BUILDER_DEPSOLVE_TRACE) and
Python-side (bench/depsolve_timed.py) tracing. Runs inside the Fedora 44
benchmark container. Writes <out>/results.jsonl (one line per run).

Example:
  run_matrix.py --out runs/warm --images generic-qcow2,minimal-raw-xz --reps 5
"""
import argparse
import json
import os
import shutil
import subprocess
import time

ROOT = "/workspace/depsolve-perf"
IB = f"{ROOT}/bin/image-builder"
TIMED = f"{ROOT}/bench/osbuild-depsolve-dnf-timed"
PLAIN = f"{ROOT}/bench/osbuild-depsolve-dnf-plain"

VARIANTS = {
    # current upstream behaviour: full metadata + depsolver-side SPDX SBOM
    "today": {"exp": "", "dnf": TIMED},
    # full metadata, SBOM to be generated in image-builder (future design)
    "full": {"exp": "depsolve-no-sbom", "dnf": TIMED},
    # Achilleas' lean variant: only what the manifest needs
    "minimal": {"exp": "depsolve-no-sbom,depsolve-package-metadata=minimal", "dnf": TIMED},
    # worst case: full metadata including file lists
    "full_files": {"exp": "depsolve-no-sbom,depsolve-optional-metadata=filelists", "dnf": TIMED},
    # timer overhead check: like "today"/"full"/"minimal" but without the Python harness
    "today_plain": {"exp": "", "dnf": PLAIN},
    "full_plain": {"exp": "depsolve-no-sbom", "dnf": PLAIN},
    "minimal_plain": {"exp": "depsolve-no-sbom,depsolve-package-metadata=minimal", "dnf": PLAIN},
}


def read_jsonl(path):
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def run_one(out, image, variant, solver, rep, cache_mode, cachedir, record=True):
    rid = f"{image}.{variant}.{solver}.{cache_mode}.{rep}"
    rdir = os.path.join(out, "raw", rid)
    shutil.rmtree(rdir, ignore_errors=True)
    os.makedirs(rdir)
    if cache_mode == "cold":
        shutil.rmtree(cachedir, ignore_errors=True)
    v = VARIANTS[variant]
    env = dict(os.environ)
    env.update({
        "OSBUILD_DEPSOLVE_DNF": v["dnf"],
        "OSBUILD_SOLVER_CONFIG": f"{ROOT}/bench/solver-{solver}.json",
        "IMAGE_BUILDER_DEPSOLVE_TRACE": f"{rdir}/go.jsonl",
        "PERF_PY_TRACE": f"{rdir}/py.jsonl",
        "IMAGE_BUILDER_EXPERIMENTAL": v["exp"],
    })
    if not v["exp"]:
        env.pop("IMAGE_BUILDER_EXPERIMENTAL")
    cmd = ["/usr/bin/time", "-f", "%e %M %U %S", "-o", f"{rdir}/time.txt",
           IB, "manifest", image, "--distro", "fedora-44", "--rpmmd-cache", cachedir]
    t = time.perf_counter()
    with open(f"{rdir}/manifest.json", "wb") as mf, open(f"{rdir}/stderr.txt", "wb") as ef:
        rc = subprocess.call(cmd, stdout=mf, stderr=ef, env=env)
    wall = time.perf_counter() - t
    with open(f"{rdir}/time.txt", encoding="utf-8") as f:
        tl = f.read().strip().splitlines()[-1].split()
    rec = {
        "run": rid, "image": image, "variant": variant, "solver": solver, "rep": rep, "cache": cache_mode,
        "rc": rc, "wall_s": wall, "time_elapsed_s": float(tl[0]), "ib_maxrss_kib": int(tl[1]),
        "ib_user_s": float(tl[2]), "ib_sys_s": float(tl[3]),
        "manifest_bytes": os.path.getsize(f"{rdir}/manifest.json"),
        "go": read_jsonl(f"{rdir}/go.jsonl"), "py": read_jsonl(f"{rdir}/py.jsonl"),
    }
    if rc != 0:
        with open(f"{rdir}/stderr.txt", encoding="utf-8", errors="replace") as f:
            rec["stderr_tail"] = f.read()[-2000:]
    if record:
        with open(os.path.join(out, "results.jsonl"), "a", encoding="utf-8") as f:
            f.write(json.dumps(rec) + "\n")
    # keep the manifests of the first rep only (space)
    if rep > 0 or not record:
        os.remove(f"{rdir}/manifest.json")
    print(f"{rid}: rc={rc} wall={wall:.2f}s", flush=True)
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--images", default="generic-qcow2")
    ap.add_argument("--variants", default="today,full,minimal,full_files")
    ap.add_argument("--solvers", default="dnf4,dnf5")
    ap.add_argument("--reps", type=int, default=5)
    ap.add_argument("--cache", choices=["warm", "cold"], default="warm")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    for solver in a.solvers.split(","):
        cachedir = f"{ROOT}/cache/{a.cache}-{solver}"
        for image in a.images.split(","):
            if a.cache == "warm":
                # warm-up (not recorded): populate the cache for this image/solver,
                # incl. filelists if needed
                for variant in a.variants.split(","):
                    run_one(a.out, image, variant, solver, -1, a.cache, cachedir, record=False)
            for rep in range(a.reps):
                for variant in a.variants.split(","):
                    run_one(a.out, image, variant, solver, rep, a.cache, cachedir)


if __name__ == "__main__":
    main()

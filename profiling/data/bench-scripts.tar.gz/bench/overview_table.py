#!/usr/bin/env python3
"""Compact overview tables from runs/<mode>/summary.json (medians) -> runs/<mode>/overview.md"""
import json, sys
mode = sys.argv[1] if len(sys.argv) > 1 else "warm"
d = json.load(open(f"runs/{mode}/summary.json"))
images = []
for k in d:
    i = k.split("|")[0]
    if i not in images: images.append(i)
out = []
for solver in ("dnf4", "dnf5"):
    out += [f"\n**{solver}, {mode} cache** (medians; seconds unless noted; metadata = Py convert+disjoint+dict+dumps+write + Go unmarshal+convert)\n",
            "| image (pkgs) | variant | wall | repo load | resolve | Py convert | SBOM (py) | dumps+write | Go unmarshal | metadata total | share | IB rest | payload MB | Py RSS MiB | Go RSS MiB |",
            "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for i in images:
        for v in ("today", "full", "minimal", "full_files"):
            s = d.get(f"{i}|{solver}|{v}|{mode}")
            if not s: continue
            out.append(f"| {i} ({int(s['packages'])}) | {v} | {s['wall']:.2f} | {s['repo_load']:.2f} | {s['depsolve']:.2f} | "
                       f"{s['pkg_convert']:.2f} | {s['sbom']:.2f} | {s['json_dumps']+s['write']:.3f} | {s['go_unmarshal']:.3f} | "
                       f"{s['metadata_cost']:.2f} | {100*s['metadata_share']:.1f}% | {s['ib_rest']:.2f} | {s['bytes']/1e6:.1f} | "
                       f"{s['py_maxrss_mib']:.0f} | {s['go_maxrss_mib']:.0f} |")
open(f"runs/{mode}/overview.md", "w").write("\n".join(out) + "\n"); print("\n".join(out))
